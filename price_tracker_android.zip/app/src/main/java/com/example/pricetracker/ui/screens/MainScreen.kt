package com.example.pricetracker.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Category(val name: String)

@Composable
fun MainScreen() {
    var text by remember { mutableStateOf("") }
    val categories = remember { mutableStateListOf<Category>() }

    Column(modifier = Modifier.padding(16.dp)) {

        Text("Price Tracker", style = MaterialTheme.typography.headlineMedium)

        Spacer(Modifier.height(12.dp))

        Row {
            TextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                label = { Text("Новая категория") }
            )

            Spacer(Modifier.width(8.dp))

            Button(onClick = {
                if (text.isNotBlank()) {
                    categories.add(Category(text))
                    text = ""
                }
            }) {
                Text("Добавить")
            }
        }

        Spacer(Modifier.height(16.dp))

        LazyColumn {
            items(categories) { cat ->
                Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    Text(cat.name, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}