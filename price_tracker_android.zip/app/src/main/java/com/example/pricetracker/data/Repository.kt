package com.example.pricetracker.data

class Repository {
    // Later: API calls to backend + price tracking
}